//
//  HairCareNetworkClient.swift
//  HairCare
//
//  Created by Taylor Lyles on 8/26/19.
//  Copyright © 2019 Taylor Lyles. All rights reserved.
//

import Foundation

struct HairCareNetworkClient {
	
//    static let haircareURL = URL(string: "")!
//
//    func fetchHairStylist(completion: @escaping ([HairStylist]?, Error?) -> Void) {
//        URLSession.shared.dataTask(with: HairCareNetworkClient.haircareURL) { (data, _, error) in
//            if let error = error {
//                completion(nil, error)
//                return
//            }
//
//            guard let data = data else {
//                completion(nil, NSError())
//                return
//            }
//
//            do {
//                let recipes = try JSONDecoder().decode([HairStylist].self, from: data)
//                completion(recipes, nil)
//            } catch {
//                completion(nil, error)
//                return
//            }
//            }.resume()
//    }
}
