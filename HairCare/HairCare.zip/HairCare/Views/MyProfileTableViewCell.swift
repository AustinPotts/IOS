//
//  MyProfileTableViewCell.swift
//  HairCare
//
//  Created by Austin Potts on 8/26/19.
//  Copyright © 2019 Taylor Lyles. All rights reserved.
//

import UIKit

class MyProfileTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
