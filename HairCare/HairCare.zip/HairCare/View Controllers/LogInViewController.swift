//
//  LogInViewController.swift
//  HairCare
//
//  Created by Austin Potts on 8/27/19.
//  Copyright © 2019 Taylor Lyles. All rights reserved.
//

import UIKit

class LogInViewController: UIViewController {

    
    
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    @IBAction func logInTapped(_ sender: Any) {
    }
    
    @IBAction func createProfileTapped(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
